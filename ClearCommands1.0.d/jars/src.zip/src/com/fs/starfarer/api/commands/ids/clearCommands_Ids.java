package com.fs.starfarer.api.commands.ids;

public class clearCommands_Ids {
    public static final String NO_CLEAR_KEY = "$clearCommands_no_remove";
}
