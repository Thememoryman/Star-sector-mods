package data.scripts.world;

/**
 * this is just a dummy class with the old name so the mod factions can find it
 */
@Deprecated
public class ExerelinGen {

}